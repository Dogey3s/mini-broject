1. Edit Accordingly in the .tex file.
2. It's Recommended to compile main_report.tex file after editing in different .tex files.
3. Remove Instructions which are given as hints.
4. To generate Table Online, goto:
    http://www.tablesgenerator.com/
5. Don't run/compile .tex file when the .pdf is open
6. If error like " PACKAGE_NAME.sty not found ", don't panic.
   Go to "MikTex Package Manager", search for the PACKAGE_NAME and install.(Windows User, using MikTex)
7. To make flowchart/block diagram, once visit 
   "draw.io"
8. Any Errors/mistakes, let's know.  